#' @title Addition
#' @description Basic addition
#' 
#' @param x one value
#' @param y next value
#' 
#' @details 
#' 
#' @return an integer
#' 
#' @examples add <- addition(1,2)
#' 
#' @export


addition <- function(x,y){
  a <- x + y
  return(a)
}