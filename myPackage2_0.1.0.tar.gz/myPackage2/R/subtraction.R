#' @title Subtraction
#' @description Basic subtraction
#' 
#' @param x one value
#' @param y next value
#' 
#' @details 
#' 
#' @return an integer
#' 
#' @examples sub <- subtraction(5,2)
#' 
#' @export


subtraction <- function(x,y){
  a <- x - y
  return(a)
}