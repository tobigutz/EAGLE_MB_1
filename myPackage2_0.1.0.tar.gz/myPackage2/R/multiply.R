#' @title Multiply
#' @description Basic division
#' 
#' @param x one value
#' @param y next value
#' 
#' @details 
#' 
#' @return an integer
#' 
#' @examples mutli <- multiply(5,5)
#' 
#' @export


multiply <- function(x,y){
  a <- x * y
  return(a)
}